import core.client as client
client.main()
