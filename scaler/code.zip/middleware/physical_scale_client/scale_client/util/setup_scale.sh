#!/bin/bash

cp scale /etc/init.d/

update-rc.d scale defaults
