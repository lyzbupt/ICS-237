python -m unittest scale_client.core.tests.test_sensed_event
