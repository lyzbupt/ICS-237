import logging
import pymysql
import pymysql.cursors
import datetime
from datetime import date
from datetime import timedelta
log = logging.getLogger(__name__)

from scale_client.sensors.dummy.dummy_virtual_sensor import DummyVirtualSensor

class ConditionSensor(DummyVirtualSensor):
    """
    This sensor simply publishes a heartbeat event every sample_interval seconds, which is
    useful for ensuring a remote client is alive and connected to the data exchange.
    """

    def __init__(self, broker, static_event_data="condition", event_type="condition", sample_interval=5, **kwargs):
        super(ConditionSensor, self).__init__(broker=broker, static_event_data=static_event_data,
                                              event_type=event_type, sample_interval=sample_interval, **kwargs)

    def read_raw(self):
        conn = pymysql.connect(host='***', port=3306, user='***', 
            password='***', db='vaData', charset='utf8', cursorclass=pymysql.cursors.DictCursor)
        cursor = conn.cursor()
        out = ''
        time = date.today().strftime("%Y%m%d")
        try:
            sql = "SELECT * from cond_"+time
            cursor.execute(sql)
            result=cursor.fetchall()
            for data in result:
                out = out+str(data['hour'])+':'
                out = out+data['cond']+','
        finally:
            conn.close()
        return out

    DEFAULT_PRIORITY = 10
