import logging
import pandas as pd
import datetime
from datetime import date
from datetime import timedelta
import re
log = logging.getLogger(__name__)

from scale_client.sensors.dummy.dummy_virtual_sensor import DummyVirtualSensor

class PressureSensor(DummyVirtualSensor):

	def __init__(self,broker,static_event_data="30",event_type="pressure",sample_interval=10,**kwargs):
		super(PressureSensor,self).__init__(broker=broker, static_event_data=static_event_data,
											event_type=event_type,sample_interval=sample_interval,**kwargs)

	def read_raw(self):
		url = "https://www.wunderground.com/history/airport/KSNA/"
		req_city = "req_city=irvine"
		req_state = "req_state=CA"
		req_statename = "req_statename=California"
		reqdb_zip = "reqdb.zip=92612"
		req = '&'.join([req_city, req_state, req_statename, reqdb_zip])
		time = date.today().strftime("%Y/%m/%d")
		tmp = '/'.join([url, str(time), 'DailyHistory.html?' + req])
		tables = pd.read_html(tmp)
		res = tables[-1].values
		res = res[-1]
		res = res[4]
		pressure = float(re.findall(r"\d+\.?\d*", res)[0])
		return pressure

	DEFAULT_PRIORITY = 10