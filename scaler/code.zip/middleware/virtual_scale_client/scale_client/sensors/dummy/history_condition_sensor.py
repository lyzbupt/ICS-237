import logging
import pandas as pd
import datetime
from datetime import date
from datetime import timedelta
import re
log = logging.getLogger(__name__)

from scale_client.sensors.dummy.dummy_virtual_sensor import DummyVirtualSensor

class HistoryConditionSensor(DummyVirtualSensor):
    """
    This sensor simply publishes a heartbeat event every sample_interval seconds, which is
    useful for ensuring a remote client is alive and connected to the data exchange.
    """

    def __init__(self, broker, static_event_data="sunny", event_type="current_condition", sample_interval=10, **kwargs):
        super(HistoryConditionSensor, self).__init__(broker=broker, static_event_data=static_event_data,
                                              event_type=event_type, sample_interval=sample_interval, **kwargs)

    def read_raw(self):
        url = "https://www.wunderground.com/history/airport/KSNA/"
        req_city = "req_city=irvine"
        req_state = "req_state=CA"
        req_statename = "req_statename=California"
        reqdb_zip = "reqdb.zip=92612"
        req = '&'.join([req_city, req_state, req_statename, reqdb_zip])
        time = date.today().strftime("%Y/%m/%d")
        tmp = '/'.join([url, str(time), 'DailyHistory.html?' + req])
        print(tmp)
        tables = pd.read_html(tmp)
        res = tables[-1].values
        print(res)
        res = res[-1]
        print(res)
        condition = res[-1]
        return condition

    DEFAULT_PRIORITY = 10